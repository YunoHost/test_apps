<?php

// Database
define('DB_NAME', 'wordpress');
define('DB_USER', 'wordpress');
define('DB_PASSWORD', 'r1RT5UdPV2TQDtFuV4Df');
define('DB_HOST', 'localhost');
define('DB_CHARSET', 'utf8');
define('DB_COLLATE', '');

// Keys
define('AUTH_KEY',         'laqeOr8ScdOEkx5KTH9hHvsbFjbWB9i5Wr46b0kO');
define('SECURE_AUTH_KEY',  'A8W3iI2PIQQi86]3MwKlegQJpuRCdU6ud]0xc4lO');
define('LOGGED_IN_KEY',    'XyGA5rj]iSyOODOF]mT0tOs6Q3BLAGBzc[yv2GtK');
define('NONCE_KEY',        'EkjAspho1vSbyq23mCulkubyowu05ciqwdCy49c9');
define('AUTH_SALT',        'iLnkBaVV0wgG9qU0H0CLh5Hhz]KBzSUVEV7abiz4');
define('SECURE_AUTH_SALT', 'DL[vcwQvW4JtgzVDn9BjbxuSWX0IAdmTBoeSJ6o2');
define('LOGGED_IN_SALT',   'MtmWx66xXyMHJdGktZw6kAFqxpNlgxQXNb]ua7DG');
define('NONCE_SALT',       'lyjtPfZIbqXcS82ZwP3Wy5cJRXIdNWGbvREc5GrE');

// Prefix
$table_prefix  = 'wp_';

// Debug mode
define('WP_DEBUG', false); 

// Multisite
//--MULTISITE1--define('WP_ALLOW_MULTISITE', true);
//--MULTISITE2--define('MULTISITE', true);
//--MULTISITE2--define('SUBDOMAIN_INSTALL', false);
//--MULTISITE2--define('DOMAIN_CURRENT_SITE', 'yolo.test');
//--MULTISITE2--define('PATH_CURRENT_SITE', '/blog/');
//--MULTISITE2--define('SITE_ID_CURRENT_SITE', 1);
//--MULTISITE2--define('BLOG_ID_CURRENT_SITE', 1);

// Path
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

// WordPress settings path
require_once(ABSPATH . 'wp-settings.php');

// Force https redirect
define('FORCE_SSL_ADMIN', true);

// Auto update
define('WP_AUTO_UPDATE_CORE', 'minor');
add_filter( 'auto_update_plugin', '__return_true' );
add_filter( 'auto_update_theme', '__return_true' );
