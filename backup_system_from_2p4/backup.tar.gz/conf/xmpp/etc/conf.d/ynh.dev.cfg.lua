VirtualHost "ynh.dev"
  ssl = {
        key = "/etc/yunohost/certs/ynh.dev/key.pem";
        certificate = "/etc/yunohost/certs/ynh.dev/crt.pem";
  }
  authentication = "ldap2"
  ldap = {
     hostname      = "localhost",
     user = {
       basedn        = "ou=users,dc=yunohost,dc=org",
       filter        = "(&(objectClass=posixAccount)(mail=*@ynh.dev))",
       usernamefield = "mail",
       namefield     = "cn",
       },
  }
