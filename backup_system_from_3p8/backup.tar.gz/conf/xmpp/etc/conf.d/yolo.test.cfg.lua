VirtualHost "yolo.test"
  enable = true
  ssl = {
        key = "/etc/yunohost/certs/yolo.test/key.pem";
        certificate = "/etc/yunohost/certs/yolo.test/crt.pem";
  }
  authentication = "ldap2"
  ldap = {
     hostname      = "localhost",
     user = {
       basedn        = "ou=users,dc=yunohost,dc=org",
       filter        = "(&(objectClass=posixAccount)(mail=*@yolo.test)(permission=cn=xmpp.main,ou=permission,dc=yunohost,dc=org))",
       usernamefield = "mail",
       namefield     = "cn",
       },
  }

  -- Discovery items
  disco_items = {
    { "muc.yolo.test" },
    { "pubsub.yolo.test" },
    { "jabber.yolo.test" },
    { "vjud.yolo.test" },
    { "xmpp-upload.yolo.test" },
  };

--  contact_info = {
--    abuse = { "mailto:abuse@yolo.test", "xmpp:admin@yolo.test" };
--    admin = { "mailto:root@yolo.test", "xmpp:admin@yolo.test" };
--  };

------ Components ------
-- You can specify components to add hosts that provide special services,
-- like multi-user conferences, and transports.

---Set up a MUC (multi-user chat) room server
Component "muc.yolo.test" "muc"
  name = "yolo.test Chatrooms"

  modules_enabled = {
    "muc_limits";
    "muc_log";
    "muc_log_mam";
    "muc_log_http";
    "muc_vcard";
  }

  muc_event_rate = 0.5
  muc_burst_factor = 10
  room_default_config = {
    logging = true,
    persistent = true
  };

---Set up a PubSub server
Component "pubsub.yolo.test" "pubsub"
  name = "yolo.test Publish/Subscribe"

  unrestricted_node_creation = true -- Anyone can create a PubSub node (from any server)

---Set up a HTTP Upload service
Component "xmpp-upload.yolo.test" "http_upload"
  name = "yolo.test Sharing Service"

  http_file_path = "/var/xmpp-upload/yolo.test/upload"
  http_external_url = "https://xmpp-upload.yolo.test:443"
  http_file_base_path = "/upload"
  http_file_size_limit = 6*1024*1024
  http_file_quota = 60*1024*1024
  http_upload_file_size_limit = 100 * 1024 * 1024 -- bytes
  http_upload_quota = 10 * 1024 * 1024 * 1024 -- bytes

---Set up a VJUD service
Component "vjud.yolo.test" "vjud"
  vjud_disco_name = "yolo.test User Directory"
