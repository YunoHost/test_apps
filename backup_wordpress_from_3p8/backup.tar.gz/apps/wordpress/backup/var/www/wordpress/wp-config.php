<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
*/

/** Disable the wordress cron because it's managed by the system */
define('DISABLE_WP_CRON', true);

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress');

/** MySQL database username */
define('DB_USER', 'wordpress');

/** MySQL database password */
define('DB_PASSWORD', '5O0PPo8D8s6JB9Z4x3OtuEkd');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
*/
define('AUTH_KEY',         'ZkkZJjL9fZPG2BkMhWk6oQKiqvTWYNjTREYqUg9M');
define('SECURE_AUTH_KEY',  '9FU7LtKiVuTQ4TS0WD3xvH43eAgoxtAj6IZ68GcW');
define('LOGGED_IN_KEY',    'fto2SIQ64TzWzLwm2Vee7lwO0pKNueRBZzVMC6H4');
define('NONCE_KEY',        'vITRJ3tc8EFDcIxaDPJDGZzkZeeJwYA1dXpyCM5s');
define('AUTH_SALT',        'BJR0Ns8EqES3zDEjbOzJHt1jWcqIbQjgshU4lwIm');
define('SECURE_AUTH_SALT', 'UESsO2uv3sPLRlcq5ysHh39pK254CRUME6TP5a8A');
define('LOGGED_IN_SALT',   'Y4elIQTT6Cg6LPAjkWI3ZVakTdRKiV9UWiVdH2dV');
define('NONCE_SALT',       '4SxnoB5mPbWe4j7brBK6UvJRNuq8He5vF1xQY5lX');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
*/
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
*/
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

// Force https redirect
//--PUBLIC--define('FORCE_SSL_ADMIN', true);
